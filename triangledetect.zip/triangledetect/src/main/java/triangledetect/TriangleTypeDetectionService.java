package triangledetect;

public interface TriangleTypeDetectionService {

	TriangleType detectTriangleType(TriangleDto triangle);
	
}
