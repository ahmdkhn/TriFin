package triangledetect.exception;

public class IncompleteCommandLineArgumentsException extends Exception{

	private static final long serialVersionUID = 4801493503053306424L;

	public IncompleteCommandLineArgumentsException() {
		super("Incomple Command Line Arguments");
	}

	public IncompleteCommandLineArgumentsException(String message) {
		super(message);
	}
}
