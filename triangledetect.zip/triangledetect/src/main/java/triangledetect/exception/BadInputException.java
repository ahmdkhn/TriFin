package triangledetect.exception;

public class BadInputException extends Exception{

	private static final long serialVersionUID = 4801493503053306424L;

	public BadInputException() {
		super("Bad Input Exception");
	}

	public BadInputException(String message) {
		super(message);
	}
}
