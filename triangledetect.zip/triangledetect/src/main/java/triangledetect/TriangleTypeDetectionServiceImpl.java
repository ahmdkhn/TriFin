package triangledetect;

public class TriangleTypeDetectionServiceImpl implements TriangleTypeDetectionService {

	public TriangleType detectTriangleType(TriangleDto triangle) {
		if (triangle.getSide1()==triangle.getSide2() && triangle.getSide3()==triangle.getSide2()) {
			return TriangleType.EQUILATERAL;
		} else if (triangle.getSide1()==triangle.getSide2() || triangle.getSide3()==triangle.getSide2()) {
			return TriangleType.ISOSCELES;
		} else {
			return TriangleType.SCALENE;
		}
	}
}
