package triangledetect;

public enum TriangleType {
	EQUILATERAL, ISOSCELES, SCALENE
}
