package triangledetect;

public class TriangleTypeDetectionController {

	private TriangleTypeDetectionService triangleTypeDetectionService;
	
	public TriangleTypeDetectionController(TriangleTypeDetectionService triangleTypeDetectionService) {
		this.triangleTypeDetectionService = triangleTypeDetectionService;
	}
	
	public String detectTriangleType(String [] validArgs){
		TriangleDto triangle=mapToTriangle(validArgs);
		return String.format(
				"Type of triangle is %s",
				triangleTypeDetectionService.detectTriangleType(triangle)
		);
	}
	
	protected TriangleDto mapToTriangle(String [] sideMeasurements) {
		TriangleDto triangleDto= new TriangleDto(
				Double.parseDouble(sideMeasurements[0]),
				Double.parseDouble(sideMeasurements[1]), 
				Double.parseDouble(sideMeasurements[2]) 
		);
		return triangleDto;
	}
}
