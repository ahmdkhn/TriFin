package triangledetect.main;

import triangledetect.TriangleMeasurementValidator;
import triangledetect.TriangleTypeDetectionController;
import triangledetect.TriangleTypeDetectionService;
import triangledetect.TriangleTypeDetectionServiceImpl;
import triangledetect.exception.BadInputException;
import triangledetect.exception.IncompleteCommandLineArgumentsException;

public class Driver {

	public static void main(String [] args) {
		//Wiring
		TriangleMeasurementValidator validator= new TriangleMeasurementValidator();
		TriangleTypeDetectionService triangleTypeDetectionService = new TriangleTypeDetectionServiceImpl();
		TriangleTypeDetectionController controller = new TriangleTypeDetectionController(triangleTypeDetectionService);
		
		
		try {
			//Validation
			validator.validate(args);
			
			//Logic Controller
			String result = controller.detectTriangleType(args);
			
			//Output: Echo Response
			System.out.println("Output:");
			System.out.println(
				String.format("\tType of triangle is %s", result)
			);

			
		} catch (BadInputException e) {
			System.out.println("Recieved Bad Request.");
			System.out.println("Underlying Exception is " + e.getMessage());
			e.printStackTrace();

		} catch (IncompleteCommandLineArgumentsException e) {
			System.out.println(e.getMessage());
			System.out.println("Usage: You need to specify traingle side measurments using command line arguments");
			System.out.println("For example:  mvn clean install exec:java -Dside1.length=20.0 -Dside2.length=20.0 -Dside3.length=30.0");
			System.out.println("Underlying Exception is " + e.getMessage());
			e.printStackTrace();
		}
	}
}
