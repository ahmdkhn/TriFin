package triangledetect;

import org.apache.commons.lang.math.NumberUtils;

import triangledetect.exception.BadInputException;
import triangledetect.exception.IncompleteCommandLineArgumentsException;

public class TriangleMeasurementValidator {
	
	public boolean validate(String [] args) throws BadInputException, IncompleteCommandLineArgumentsException {
		validateAllThreeArgumentsArePresent(args);
		validateIfAnArgumentIsNull(args);
		validateAllThreeArgumentsAreNumbers(args);
		return true;
	}
	
	protected void validateAllThreeArgumentsArePresent(String [] args) throws IncompleteCommandLineArgumentsException {
		if (args.length!=3) {
			throw new IncompleteCommandLineArgumentsException("All three sides of Triangle are not specified." + args.length);
		}
	}
	
	protected void validateIfAnArgumentIsNull(String [] args) throws IncompleteCommandLineArgumentsException {
		for (String arg: args) {
			if (arg==null) {
				throw new IncompleteCommandLineArgumentsException();
			}
		}
	}
	
	protected void validateAllThreeArgumentsAreNumbers(String [] args) throws BadInputException {
		for (String arg: args) {
			if (!NumberUtils.isNumber(arg)) {
				throw new BadInputException(
					String.format(
						"%s is not a number. All sides of triangle must be number", 
						arg
					)
				);
			}
		}
	}

}
