package triangledetect.integration;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

import triangledetect.TriangleDto;
import triangledetect.TriangleType;
import triangledetect.TriangleTypeDetectionController;
import triangledetect.TriangleTypeDetectionService;
import triangledetect.TriangleTypeDetectionServiceImpl;

public class TriangleTypeDetectionControllerTest {

	private TriangleTypeDetectionService service = new TriangleTypeDetectionServiceImpl();
	private TriangleTypeDetectionController controller=new TriangleTypeDetectionController(service);
	
	@Test
	public void testEqulateralTriangleSpecification() {
		String [] args = {"10", "10", "10"};
		assertEquals("Type of triangle is EQUILATERAL", controller.detectTriangleType(args));
	}
	
	@Test
	public void testIssoscelesTriangleSpecification() {
		String [] args = {"10", "20", "20"}; 
		assertEquals("Type of triangle is ISOSCELES", controller.detectTriangleType(args));
	}

	@Test
	public void testScaleneTriangleSpecification() {
		String [] args = {"10", "20", "30"}; 
		assertEquals("Type of triangle is SCALENE", controller.detectTriangleType(args));
	}
	
}
