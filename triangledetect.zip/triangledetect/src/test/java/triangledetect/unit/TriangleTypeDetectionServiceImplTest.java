package triangledetect.unit;

import org.junit.Test;
import static org.junit.Assert.assertEquals;

import triangledetect.TriangleDto;
import triangledetect.TriangleType;
import triangledetect.TriangleTypeDetectionServiceImpl;

public class TriangleTypeDetectionServiceImplTest {

	private TriangleTypeDetectionServiceImpl service=new TriangleTypeDetectionServiceImpl();
	
	@Test
	public void testEqulateralTriangleSpecification() {
		TriangleDto triangle= new TriangleDto(10.0, 10.0, 10.0); 
		assertEquals(TriangleType.EQUILATERAL, service.detectTriangleType(triangle));
	}
	
	@Test
	public void testIssoscelesTriangleSpecification() {
		TriangleDto triangle= new TriangleDto(10.0, 10.0, 20.0); 
		assertEquals(TriangleType.ISOSCELES, service.detectTriangleType(triangle));
	}

	@Test
	public void testScaleneTriangleSpecification() {
		TriangleDto triangle= new TriangleDto(10.0, 20.0, 30.0); 
		assertEquals(TriangleType.SCALENE, service.detectTriangleType(triangle));
	}
}
