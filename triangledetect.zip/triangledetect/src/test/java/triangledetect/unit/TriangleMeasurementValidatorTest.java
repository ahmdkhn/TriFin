package triangledetect.unit;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

import triangledetect.TriangleMeasurementValidator;
import triangledetect.exception.BadInputException;
import triangledetect.exception.IncompleteCommandLineArgumentsException;

public class TriangleMeasurementValidatorTest {

	private TriangleMeasurementValidator validator = new TriangleMeasurementValidator();
	
	@Test(expected=IncompleteCommandLineArgumentsException.class)
	public void testNullArguments() throws BadInputException, IncompleteCommandLineArgumentsException {
		String [] args = {};
		validator.validate(args);
	}

	@Test(expected=IncompleteCommandLineArgumentsException.class)
	public void testIncompleteNumberOfArguments() throws BadInputException, IncompleteCommandLineArgumentsException {
		String [] args = {"10.0","20.0"};
		validator.validate(args);
	}

	@Test(expected=BadInputException.class)
	public void testAllNonNumberArguments() throws BadInputException, IncompleteCommandLineArgumentsException {
		String [] args = {"a","b", "c"};
		validator.validate(args);
	}
	
	@Test(expected=BadInputException.class)
	public void testEmptyArguments() throws BadInputException, IncompleteCommandLineArgumentsException {
		String [] args = {"","",""};
		validator.validate(args);
	}
	
	public void testWithCorrectArguments() throws BadInputException, IncompleteCommandLineArgumentsException {
		String [] args = {"10", "20", "30"};
		validator.validate(args);
	}
}
